package q1;


/**
 * Stickman.
 * @author Jay Lin
 * @version 1.0
 */
public class Stickman {
    /**
     * Drives the program.
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        System.out.println("\t\t   /'''''\\");
        System.out.println("\t\t  | (o|o) |");
        System.out.println("\t\t  |'-----'|");
        System.out.println("\t\t   \\_____/");
        System.out.println("\t\t  ___| |___");
        System.out.println("\t\t /   '-'   \\");
        System.out.println("\t\t|  .     .  |");
        System.out.println("\t\t \\_|_____|_/");
        System.out.println("\t\t /_|     |_\\");
        System.out.println("\t\t  |  .-.  |");
        System.out.println("\t\t  '._| |_.'");
        System.out.println("\t\t  /__| |__\\");
        System.out.println("Question one was called and ran sucessfully.");
    }

};
