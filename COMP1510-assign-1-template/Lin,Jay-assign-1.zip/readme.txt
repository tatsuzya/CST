[Jay Lin], [A00850058], [Set D], [Feb 2 2017]

This assignment is [100]% complete.


------------------------
Question one (Stickman) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (SecondsConvert) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (Pack) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question four (Cylinder) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question five (BusinessCard) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]
