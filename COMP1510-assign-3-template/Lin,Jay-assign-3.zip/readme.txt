[Jay Lin], [A00850058], [Set D], [Mar 28 2017]

This assignment is [100]% complete.


------------------------
Question one (PalindromeTester) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (RockPaperScissors) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (TestStudent and supporting classes) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question four (Primes and supporting classes) status: complete

[complete or not complete] 
[explanation if not complete, what is working/not working]

------------------------
