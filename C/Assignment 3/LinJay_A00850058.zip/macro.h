#ifndef MACRO_H
#define MACRO_H 

#define ignorecase 1u
#define ignorews 2u
#define reverse 4u

#define LINESIZE 1024 

#endif
