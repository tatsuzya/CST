#ifndef TYPES_H
#define TYPES_H
#define IDSIZE  10

typedef struct {
  char id[IDSIZE];
  int  score;
} Grade;
#endif

