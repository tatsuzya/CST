#ifndef IO_H
#define IO_H
#include "types.h"

int read_grade(Grade *);
void print_grade(const Grade *);

#endif
