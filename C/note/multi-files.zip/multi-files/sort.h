#ifndef SORT_H
#define SORT_H
#include "types.h"

void sort_by_id(Grade *a, size_t n);
#endif
