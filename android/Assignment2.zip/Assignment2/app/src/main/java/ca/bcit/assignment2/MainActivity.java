package ca.bcit.assignment2;

import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private MediaPlayer media;
    private double duration = 0, endTime = 0;
    private Handler handler = new Handler();
    private SeekBar seekbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initial();
    }
    public void initial(){
        media = MediaPlayer.create(this, R.raw.test);
        endTime = media.getDuration();
        seekbar = findViewById(R.id.seekBar);
        seekbar.setMax((int)endTime);
    }

    public void play(View view){
        media.start();
        duration = media.getCurrentPosition();
        seekbar.setProgress((int)duration);
        handler.postDelayed(updateTime,100);
    }
    private Runnable updateTime = new Runnable(){

        @Override
        public void run() {
            duration = media.getCurrentPosition();
            seekbar.setProgress((int)duration);
            handler.postDelayed(this,100);
        }
    };

    public void pause(View view){
        media.pause();
    }
}
