[Lin,Jay], [A00850058], [Set D], [March 1,2017]

This assignment is [100]% complete.


------------------------
Question one (TriangleArea) status: complete

[complete or not complete] 
[explanation if not complete, what is working/not working]

------------------------
Question two (CylinderStats) status: complete

[complete or not complete] 
[explanation if not complete, what is working/not working]

------------------------
Question three (Bookshelf) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question four (TrafficLight) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]
